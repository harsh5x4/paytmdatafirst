﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SDRS.Entity;
using SDRS.Exception;
using SDRS.DAL;
using System.Text.RegularExpressions;

namespace SDRS.BL
{
    public class Validations
    {
        private static bool Validation(Recharge_1381 stud)
        {
            bool studValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                if (stud.mobile_number.ToString() == string.Empty)
                {
                    message.Append("Mobile no should be provided\n");
                    studValidated = false;
                }




                else if (!Regex.IsMatch(stud.mobile_number.ToString(), "[0-9]{10}"))
                {
                    message.Append("Mobile no should have 10 digits");
                    studValidated = false;
                }

                if (studValidated == false)
                    throw new tdrsException(message.ToString());
            }
            catch (tdrsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }
        public static Consumer_1381 SearchConsumer(string scode)
        {
            Consumer_1381 stud = null;

            try
            {
                stud = Operations.SearchConsumer(scode);
                if (stud == null)
                {
                    throw new tdrsException("Invalid user");
                }
            }
            catch (tdrsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }
        public static int AddRecharge(Recharge_1381 stud)
        {
            int records = 0;

            try
            {
                if (Validation(stud))
                {
                    records = Operations.AddRecharge(stud);
                }
                else
                    throw new tdrsException("Please provide valid information");
            }
            catch (tdrsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

    }
}
