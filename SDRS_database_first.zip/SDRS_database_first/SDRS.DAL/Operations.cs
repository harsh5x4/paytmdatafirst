﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SDRS.Exception;
using SDRS.Entity;


namespace SDRS.DAL
{
    public class Operations
    {
        static TrainingEntities context = new TrainingEntities();

        public static int AddRecharge(Recharge_1381 stud)
        {
            int records = 0;

            try
            {
                context.Recharge_1381.Add(stud);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static Consumer_1381 SearchConsumer(string scode)
        {
            Consumer_1381 stud = null;

            try
            {

                stud = (from s in context.Consumer_1381
                        where s.mobile_number == scode
                        select s).FirstOrDefault();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }
    }
}
