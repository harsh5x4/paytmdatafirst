create table [dbo].Consumer_13811
(
	mobile_number varchar(20) Primary key,
	consumer_name varchar(20),
	region varchar(20)
)

create table [dbo].Recharge_13811
(
	recharge_id int identity(1,1) primary key,
	amount integer,
	validity integer,
	talktime integer,
	data integer,
	rechargedon date,
	validtilldate date,
	mobile_number varchar(20),
	FOREIGN KEY (mobile_number) REFERENCES Consumer_1381(mobile_number)
)

