﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SDRS.Entity;
using SDRS.Exception;
using SDRS.BL;
namespace SDRS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void btnVerify_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Consumer_1381 con = null;
                con = Validations.SearchConsumer((txtMobNo.Text));
                gridConsumer.DataContext = con;
                lbRecharge.Visibility = Visibility.Visible;
                btnRecharge.Visibility = Visibility.Visible;
                textConName.Text = con.consumer_name;
                textRegion.Text = con.region;
            }
            catch (tdrsException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnRecharge_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int records = Validations.AddRecharge(r);

                if (records > 0)
                {
                    MessageBox.Show("Recharge successfull!");

                }
                else
                    throw new tdrsException("Record not added");
            }
            catch (tdrsException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        Recharge_1381 r = new Recharge_1381();

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {

            r.amount = Convert.ToInt32(txtAmt.Text);
            r.validity = Convert.ToInt32(txtVal.Text);
            r.data = Convert.ToInt32(txtData.Text);
            r.talktime = Convert.ToInt32(txtTalktime.Text);
            r.rechargedon = DateTime.Today;
            r.mobile_number = (txtMobNo.Text);


        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            r.amount = Convert.ToInt32(txtAmt2.Text);
            r.validity = Convert.ToInt32(txtVal2.Text);
            r.data = Convert.ToInt32(txtData2.Text);
            r.talktime = Convert.ToInt32(txtTalktime2.Text);
            r.rechargedon = DateTime.Today;
            r.mobile_number = (txtMobNo.Text);

        }
    }
}
