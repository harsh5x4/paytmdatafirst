﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDRS.Exception
{
    public class tdrsException : ApplicationException
    {
        public tdrsException()
            : base()
        {

        }
        public tdrsException(string msg)
            : base(msg)
        {

        }
    }
}
